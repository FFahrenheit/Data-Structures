#include <iostream>
#include "Producto.h"

using namespace std;

#include "Tienda.h"

int main()
{
    Tienda t;
    t.menu();
    return 0;
}
